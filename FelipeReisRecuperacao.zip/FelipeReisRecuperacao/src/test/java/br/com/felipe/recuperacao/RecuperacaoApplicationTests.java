package br.com.felipe.recuperacao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecuperacaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
